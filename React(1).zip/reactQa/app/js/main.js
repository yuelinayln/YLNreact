var React = require('react');
var QuestionApp = require('./components/QuestionApp.js');

var mainCom = React.render(
	<QuestionApp />,
	document.getElementById('app')
)
